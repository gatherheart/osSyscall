#include <stdio.h>

int pp(int i){

	int j =0; 
	for (j = 0; j < 5; j++)
		printf("%d", j);

	return 0;

}

