extern int pp(int i);
extern int ppp(int i);

int main(){

	pp(11);
	ppp(1);

	return 0;
}
