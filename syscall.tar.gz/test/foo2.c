#include <stdio.h>

int ppp(int i){

	int j;

	for(j = 5; j < 10; j++)
		printf("%d", j);

	return 0;

}
